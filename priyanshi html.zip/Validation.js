name.addEventListener('blur',()=>{
  let reg=/(^[A-Za-z]+$){1,15}/g;
  if(!reg.test(first.value)){
   name.classList.add("error");
  }
  else{
    name.classList.remove("error");
  }

});

email.addEventListener('blur',()=>{
  let reg=/[A-Za-z0-9]@[a-z].[a-z]/;
  if(!reg.test(email.value)){
    email.classList.add("error");
  }
  else{
    email.classList.remove("error");
  }
});

mob.addEventListener('blur',()=>{
  let reg=/^91([0-9]){10}/;
  if(!reg.test(mob.value)){
    mob.classList.add("error");
  }
  else{
    mob.classList.remove("error");
  }
});

birth.addEventListener('blur',()=>{
  let reg=/^91([0-9]){10}/;
  if(!reg.test(mob.value)){
    birth.classList.add("error");
  }
  else{
    birth.classList.remove("error");
  }
});

password.addEventListener('blur',()=>{
  let reg=/[A-Za-z0-9]@[a-z].[a-z]/;
  if(!reg.test(email.value)){
    password.classList.add("error");
  }
  else{
    password.classList.remove("error");
	}
});

confrim.addEventListener('blur',()=>{
  let reg=/[A-Za-z0-9]@[a-z].[a-z]/;
  if(!reg.test(email.value)){
    confrim.classList.add("error");
  }
  else{
    confrim.classList.remove("error");
  }
});

const btn=document.getElementById("btn");
btn.addEventListener('click',()=>{
  let reg_name=/(^[A-Za-z]+$){1,15}/g;
  let reg_email=/[A-Za-z0-9]@[a-z].[a-z]/;
  let reg_mob=/([0-9]){10}/;
  let reg_birth=/([0-9]){10}/;
  let reg_password=/[A-Za-z0-9]@[a-z].[a-z]/;
  let reg_confrim=/[A-Za-z0-9]@[a-z].[a-z]/;
  if(reg_name.test(name.value)&&reg_email.test(email.value)&&reg_mob.test(mob.value)&&reg_birth.test(birth.value)&&
	  reg_password.test(password.value)&&reg_confrim.test(confrim.value))
	  {
    document.getElementById("form").setAttribute("action","log in.html");
  }
  else{
    alert("the form filled is wrong")
  }
})